// Copyright (C) 2004, International Business Machines
// Corporation and others.  All Rights Reserved.

#ifndef _CoinTypes_hpp
#define _CoinTypes_hpp

//#############################################################################

#if defined(_MSC_VER)
   typedef __int64 int64_t;
#else
#  include <climits>
#endif

//#############################################################################

#endif
